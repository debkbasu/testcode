import React from "react";
import BarChart from "./components/BarChart";
import LineChart from "./components/LineChart";
import AnotherLineChart from "./components/AnotherLineChart";
import PieChart from "./components/PieChart";
import VerticalNavbar from './components/navbar';
import Header from './components/header';
import Courses from './components/index';
import { color } from "chart.js/helpers";

function App() {

  const mystyleleft = {
    color: "white",
    width: "95%",
    height: "200px",
    float:"left",
    backgroundColor: "White",
    padding: "5px",
    fontFamily: "Arial",
    marginTop: "0px",
    marginBottom: "35px"
  };

  const mystyleText = {
    color: "white",
    width: "95%",
    float:"left",
    backgroundColor: "White",
    padding: "2px",
    fontFamily: "Arial",
    marginTop: "15px",
    textAlign: "center"
  };

  const leftdiv = {
    color: "white",
    width: "50%",
    height: "600px",
    backgroundColor: "white",
    float:"left",
    padding: "5px",
    fontFamily: "Arial",
    margin: "2px",
    align: "center",
    borderRight: '2px solid red'
  };

  const rightdiv = {
    color: "white",
    width: "45%",
    height: "600px",
    backgroundColor: "white",
    float:"right",
    padding: "5px",
    fontFamily: "Arial",
    margin: "5px",
    align: "center",
    
  };

  const mypie = {
    color: "white",
    width: "95%",
    height: "200px",
    backgroundColor: "White",
    padding: "10px",
    fontFamily: "Arial"
  };

  const navbar = {
    color: "white",
    width: "125px",
    backgroundColor: "white",
    float:"left",
    padding: "0px",
    fontFamily: "Arial",
    margin: "2px",
    align: "center"
  };

  const courseDetails = [
    { id: 1, total: 11, text: 'Applications deployed', color: '#fff', boxColor: 'rgb(9,147,192)' },
    { id: 2, total: 8, text: 'Applications certified', color: '#fff', boxColor: 'rgb(9,192,9)'},
    { id: 3, total: 7, text: "Count of major findings", color: '#fff', boxColor: '#f00' },
  ];

  return (
    <div>
     <div style={navbar}> 
        <VerticalNavbar />
      </div>
      <div> 
        <Header />
      </div>
      <div className="chart-container" style={{float: "left",width: "85%"}}>
        <div style={leftdiv}>
          <div>
            <div style={{ fontSize: '15px', color:'rgb(0,0,0)'}}>Release snapshot : R80 Sept-2024</div>
            <div className='d-flex gap-5 mt-4 '>
                                    {courseDetails.map(each => (
                                        <Courses key={each.id} each={each} />
                                    ))}
            </div>
          </div>
          <div style={mystyleleft}>
                  <BarChart />
          </div>
          <div style={mystyleleft}>
              <AnotherLineChart />
          </div>
        </div>
        <div style={rightdiv}>
          <div style={{ fontSize: '15px', color:'rgb(0,0,0)'}}>Trend of last 6 months</div>
          <div style={mystyleleft}>
              <LineChart />
          </div>
          <div style={mystyleText}>
            <div style={{ fontSize: '12px', fontWeight:'bold', color:'rgb(0,0,0)'}}>Defect distribution by percentage</div>
          </div>
          <div style={mypie}>
            <PieChart />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;

 