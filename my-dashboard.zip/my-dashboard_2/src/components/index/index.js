const Courses = (props) => {
    const { each } = props
    const { total, text, color, boxColor } = each
    const colorText = {
        color: `${color}`
    }
    return (
        <div className='d-flex flex-column align-items-center shadow course-container' style={{background: boxColor, borderRadius:'20px'}}>
            <p style={{color: {boxColor} , fontSize:30, marginBottom:0.1}}>{total} </p>
            <p style={{padding:'5px', color:'#fff'}}>{text} </p>
        </div>
    )
}

export default Courses