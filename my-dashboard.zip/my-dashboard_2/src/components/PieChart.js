// ./components/PieChart.js

import React from "react"; // Import the necessary library such as React for now.

import Chart from "chart.js/auto"; // Import the Chart.js library.

import { Pie } from "react-chartjs-2"; // In the react-chartjs-2 library, import the Pie component.


// Defined an object.
const labels = [
    "JDBC Violations",
    "Non-performant query",
    "Data leak",
    "Security",
    "Cross-domain data access violation",
  ];
  
  const dataOptions = {
    onClick: (e,legendItem) => {
    }
  };
  const pieData = [25, 20, 15, 15, 25];
  const data = {
    labels: labels,
    datasets: [
      {
        label: "Defect %",
        backgroundColor: [
          "#f56942",
          "#FFD662",
          "#DD1C1A",
          "#e612b8",
          "#f25070",
        ],
        borderColor: "#fff",
        borderWidth: 1,
        hoverBackgroundColor: [
          "#4c5b5c",
          "#946c2f",
          "#6b0f12",
          "#b25800",
          "#041f2b",
        ],
        hoverBorderColor: "#000",
        data: pieData,
      },
    ]
  };
  
  const PieChart = () => {
    return (
      <div>
        <Pie data={data} options={dataOptions} />
      </div>
    );
  };
  
  export default PieChart;
  