import React from "react"; // Importing the React library
import Chart from "chart.js/auto"; // Importing the Chart.js library
import { Line } from "react-chartjs-2"; // Importing the Line component from the react-chartjs-2 library
import { Tooltip } from "bootstrap";

// Setting up the labels for the x-axis of the chart
const chartReference = React.createRef();
const labels = ["A&D", "FT", "PT", "Pre-Prod", "UAT", "Prod"];

// Setting up the data for the chart, including the labels and datasets
const data = {
  labels: labels,
  datasets: [
    {
      label: "Defects by development stage", // Setting up the label for the dataset
      backgroundColor: "rgb(255, 99, 132)", // Setting up the background color for the dataset
      borderColor: "rgb(255, 99, 132)", // Setting up the border color for the dataset
      data: [0, 21, 10, 4, 1, 0], // Setting up the data for the dataset
      Tooltip: "Hi"
    },
  ],
};

const ctx = React.createRef("chartReference");

  const dataOptions = {
    plugins: {
      tooltip: {
        callbacks: {
          title: (e,chartElement,ctx) => {
            return "Outage ticket(s) for: "+e[0].label},
          label: (e,chartElement,ctx) => {
            var i = e.formattedValue;
            var message = [];
            for (let k = 0; k < i; k++) {
              message[k] = "CMB-HSBC-"+Math.floor((Math.random() * 990 + 10));
            }
            return message ;
          },
        }
      }
    },
  };

// Defining the LineChart component
const AnotherLineChart = () => {
  
  return (
    <div>
      <Line ref={chartReference} data={data} options={dataOptions}/> 
      
    </div>
  );
};

export default AnotherLineChart; // Exporting the LineChart component as the default export of the module
