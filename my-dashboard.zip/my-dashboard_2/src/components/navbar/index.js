import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import "./index.css"
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { faCoffee } from '@fortawesome/free-solid-svg-icons';

const VerticalNavbar = () => {
    return (
        
        <nav className="navbar navbar-expand-lg navbar-light ">
            
            <ul className="navbar-nav d-flex flex-column">
                <li className="nav-item"><FontAwesomeIcon icon={faCoffee} /><a className="nav-link" href="#" style={{background:'#fff', color:'#f00'}}>My Dashboard</a></li>
                <li className="nav-item"><a className="nav-link" href="#">Profile</a></li>
                <li className="nav-item"><a className="nav-link" href="#">Notifications</a></li>
                <li className="nav-item"><a className="nav-link" target="_blank" href="http://localhost:8080/showReports">My Reports</a></li>
                <li className="nav-item"><a className="nav-link" href="#">Settings</a></li>
            </ul>
        </nav>
    );
};

export default VerticalNavbar;