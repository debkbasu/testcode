import React from "react"; // Importing the React library
import Chart from "chart.js/auto"; // Importing the Chart.js library
import { Line } from "react-chartjs-2"; // Importing the Line component from the react-chartjs-2 library
import { Tooltip } from "bootstrap";

// Setting up the labels for the x-axis of the chart
const chartReference = React.createRef();
const labels = ["January", "February", "March", "April", "May", "June"];

// Setting up the data for the chart, including the labels and datasets
const data = {
  labels: labels,
  datasets: [
    {
      label: "Critical outages", // Setting up the label for the dataset
      backgroundColor: "rgb(255, 99, 132)", // Setting up the background color for the dataset
      borderColor: "36A2EB", // Setting up the border color for the dataset
      data: [0, 1, 0, 0, 2, 0, 1], // Setting up the data for the dataset
      Tooltip: ""
    },
  ],
};

const ctx = React.createRef("chartReference");

  const dataOptions = {
    plugins: {
      tooltip: {
        callbacks: {
          title: (e,chartElement,ctx) => {
            return "Outage ticket(s) for: "+e[0].label},
          label: (e,chartElement,ctx) => {
            var i = e.formattedValue;
            var message = [];
            for (let k = 0; k < i; k++) {
              message[k] = "CMB-HSBC-"+Math.floor((Math.random() * 90 + 10));
            }
            return message ;
          },
        }
      }
    },
  };

// Defining the LineChart component
const LineChart = () => {
  
  return (
    <div>
      <Line ref={chartReference} data={data} options={dataOptions}/> 
      
    </div>
  );
};

export default LineChart; // Exporting the LineChart component as the default export of the module
