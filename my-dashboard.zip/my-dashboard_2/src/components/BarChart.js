// ./components/BarChart.js

// Import the React library.
import React from "react";

// Import the Chart.js library.
import Chart from "chart.js/auto";

// Import the Bar component from the react-chartjs-2 library.
import { Bar } from "react-chartjs-2";
import { Button } from "bootstrap";

/**
 * Define a functional component named BarChart
 */
const BarChart = () => {
  
  const chartReference = React.createRef();
  // Define an array of labels.
  const labels = ["January", "February", "March", "April"];
  const innerLabels = ["Dependency", "Infra", "Design", "Database", "Functional", "Security"];
  const innerData = {
    labels: innerLabels,
    datasets: [
      {
        label: "Defect Count details for ",
        backgroundColor: ["rgb(10,180, 235)","rgb(0,0, 255)","rgb(10,180, 235)","rgb(0,0,255)","rgb(10,180, 235)","rgb(0,0,255)"],
        borderColor: "rgb(255, 99, 132)",
        data: [3, 3, 1, 2, 6, 2],
      },
    ],
  };
  
  // Defined an object 
  const data = {
    labels: labels,
    datasets: [
      {
        label: "Total defect count by month",
        backgroundColor: ["rgb(235, 187, 10)","rgb(255, 99, 87)","rgb(235, 187, 10)","rgb(255, 99, 87)","rgb(235, 187, 10)","rgb(255, 99, 87)"],
        borderColor: "rgb(255, 99, 132)",
        data: [4, 11, 17, 5],
      },
    ],
  };

  const ctx = React.createRef("chartReference");

  const dataOptions = {
    onClick: (e,chartElement,ctx) => {
      console.log(chartElement[0].index);
      innerData.datasets[0].label = "Total defects in "+labels[chartElement[0].index] +" by type";
      ctx.data = innerData;
      ctx.labels = innerLabels;
      ctx.options = innerDataOptions;
      ctx.update();
      ;
    }
  };

  const innerDataOptions = {
    onClick: (e,chartElement,ctx) => {
      ctx.data = data;
      ctx.labels = labels;
      ctx.options = dataOptions;
      ctx.update();
      ;
    }
  };

  
  // Return the Bar component, passing in the data object as a prop.
  return (
    <div>
      
      <Bar ref={chartReference} data={data} options={dataOptions} id="bar1"/>
      
    </div>
  );
};

// Export the BarChart component as the default export of the module.
export default BarChart;
